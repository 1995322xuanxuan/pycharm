
def f(x):
    return x*x


print("zhangsixuanzuihaokan")