import sztestlib
sztestlib.szlibone.f(1)
